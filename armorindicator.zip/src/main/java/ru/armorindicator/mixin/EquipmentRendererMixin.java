package ru.armorindicator.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.render.entity.equipment.EquipmentRenderer;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Подменяет текстуру надетой алмазной/незеритовой брони на стадию износа из пака
 * (diamond_5..55, netherite_5..95). Остальную броню и кастомные asset_id серверов не трогает.
 */
@Mixin(EquipmentRenderer.class)
public class EquipmentRendererMixin {

    @SuppressWarnings({"rawtypes", "unchecked"})
    @ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true)
    private RegistryKey armorindicator$swapAsset(RegistryKey original, @Local(argsOnly = true) ItemStack stack) {
        if (original == null || stack == null) return original;

        Identifier id = original.getValue();
        if (!"minecraft".equals(id.getNamespace())) return original;

        String path = id.getPath();
        boolean netherite = path.equals("netherite");
        boolean diamond = path.equals("diamond");
        if (!netherite && !diamond) return original;

        int max = stack.getMaxDamage();
        if (max <= 0) return original;

        // сколько прочности осталось, в процентах
        double pct = 100.0 * (max - stack.getDamage()) / max;
        pct = Math.max(0.0, Math.min(100.0, pct));

        String name;
        if (netherite) {
            // 19 стадий: 5, 10, ... 95
            int s = (int) (Math.round(pct / 5.0) * 5);
            s = Math.max(5, Math.min(95, s));
            name = "netherite_" + s;
        } else {
            // 11 стадий: 5, 10, ... 55
            int s = 5 + (int) Math.round(pct / 10.0) * 5;
            s = Math.max(5, Math.min(55, s));
            name = "diamond_" + s;
        }

        return RegistryKey.of(RegistryKey.ofRegistry(original.getRegistry()), Identifier.of("minecraft", name));
    }
}
